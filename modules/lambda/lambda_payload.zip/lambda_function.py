import json
import logging
import urllib.error
import urllib.request

logger = logging.getLogger()
logger.setLevel(logging.INFO)


def lambda_handler(event, context):
    reservation_id = event.get("reservation_id")
    api_url = event.get("api_url")

    if not reservation_id or not api_url:
        logger.error("Evento invalido: faltan reservation_id o api_url")
        raise ValueError("Evento invalido: faltan reservation_id o api_url")

    logger.info("Verificando reserva %s -> %s", reservation_id, api_url)

    req = urllib.request.Request(
        url=api_url,
        method="GET",
        headers={"Content-Type": "application/json"},
    )

    try:
        with urllib.request.urlopen(req, timeout=10) as response:
            body = json.loads(response.read().decode("utf-8"))
            logger.info(
                "Reserva %s -> status_before=%s status_after=%s action=%s",
                reservation_id,
                body.get("status_before"),
                body.get("status_after"),
                body.get("action_applied"),
            )
            return {"statusCode": 200, "body": body}
    except urllib.error.HTTPError as exc:
        logger.error("HTTP %s al verificar reserva %s", exc.code, reservation_id)
        raise
    except Exception as exc:
        logger.error("Error inesperado en reserva %s: %s", reservation_id, str(exc))
        raise
