region  = "us-east-1"
key = "dev/frontend/terraform.tfstate"
encrypt = true
bucket  = "travelhub-terraform-state-beta"
