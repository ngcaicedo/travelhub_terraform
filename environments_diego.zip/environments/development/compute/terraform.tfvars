environment          = "dev"
state_bucket         = "travelhub-terraform-state-beta"
desired_count        = 1
cors_allowed_origin  = "https://d1zot6uhy8y2us.cloudfront.net"


# Ejemplo de alarma CloudWatch para ECS CPU Utilization
alarms = [
  {
    name                = "ecs-cpu-utilization-high-users"
    comparison_operator = "GreaterThanThreshold"
    evaluation_periods  = 1
    metric_name         = "CPUUtilization"
    namespace           = "AWS/ECS"
    period              = 60
    statistic           = "Average"
    threshold           = 70
    description         = "Alarma si el uso de CPU supera el 70% en el servicio ECS users."
    actions_enabled     = true
    alarm_actions       = ["arn:aws:autoscaling:us-east-1:721351533107:scalingPolicy:...:resource/ecs/service/cluster_name/users:policyName/cpu-target-tracking-users"]
    ok_actions          = []
    dimensions = {
      ClusterName = "travelhub-dev"
      ServiceName = "travelhub-users"
    }
    treat_missing_data = "missing"
  },
  {
    name                = "ecs-cpu-utilization-high-security"
    comparison_operator = "GreaterThanThreshold"
    evaluation_periods  = 1
    metric_name         = "CPUUtilization"
    namespace           = "AWS/ECS"
    period              = 60
    statistic           = "Average"
    threshold           = 70
    description         = "Alarma si el uso de CPU supera el 70% en el servicio ECS security."
    actions_enabled     = true
    alarm_actions       = ["arn:aws:autoscaling:us-east-1:721351533107:scalingPolicy:...:resource/ecs/service/cluster_name/security:policyName/cpu-target-tracking-security"]
    ok_actions          = []
    dimensions = {
      ClusterName = "travelhub-dev"
      ServiceName = "travelhub-security"
    }
    treat_missing_data = "missing"
  },
  {
    name                = "ecs-cpu-utilization-high-reservations"
    comparison_operator = "GreaterThanThreshold"
    evaluation_periods  = 1
    metric_name         = "CPUUtilization"
    namespace           = "AWS/ECS"
    period              = 60
    statistic           = "Average"
    threshold           = 70
    description         = "Alarma si el uso de CPU supera el 70% en el servicio ECS reservations."
    actions_enabled     = true
    alarm_actions       = ["arn:aws:autoscaling:us-east-1:721351533107:scalingPolicy:...:resource/ecs/service/cluster_name/reservations:policyName/cpu-target-tracking-reservations"]
    ok_actions          = []
    dimensions = {
      ClusterName = "travelhub-dev"
      ServiceName = "travelhub-reservations"
    }
    treat_missing_data = "missing"
  },
  {
    name                = "ecs-cpu-utilization-high-payments"
    comparison_operator = "GreaterThanThreshold"
    evaluation_periods  = 1
    metric_name         = "CPUUtilization"
    namespace           = "AWS/ECS"
    period              = 60
    statistic           = "Average"
    threshold           = 70
    description         = "Alarma si el uso de CPU supera el 70% en el servicio ECS payments."
    actions_enabled     = true
    alarm_actions       = ["arn:aws:autoscaling:us-east-1:721351533107:scalingPolicy:...:resource/ecs/service/cluster_name/payments:policyName/cpu-target-tracking-payments"]
    ok_actions          = []
    dimensions = {
      ClusterName = "travelhub-dev"
      ServiceName = "travelhub-payments"
    }
    treat_missing_data = "missing"
  },
  {
    name                = "ecs-cpu-utilization-high-notifications"
    comparison_operator = "GreaterThanThreshold"
    evaluation_periods  = 1
    metric_name         = "CPUUtilization"
    namespace           = "AWS/ECS"
    period              = 60
    statistic           = "Average"
    threshold           = 70
    description         = "Alarma si el uso de CPU supera el 70% en el servicio ECS notifications."
    actions_enabled     = true
    alarm_actions       = ["arn:aws:autoscaling:us-east-1:721351533107:scalingPolicy:...:resource/ecs/service/cluster_name/notifications:policyName/cpu-target-tracking-notifications"]
    ok_actions          = []
    dimensions = {
      ClusterName = "travelhub-dev"
      ServiceName = "travelhub-notifications"
    }
    treat_missing_data = "missing"
  },
  {
    name                = "ecs-cpu-utilization-high-properties"
    comparison_operator = "GreaterThanThreshold"
    evaluation_periods  = 1
    metric_name         = "CPUUtilization"
    namespace           = "AWS/ECS"
    period              = 60
    statistic           = "Average"
    threshold           = 70
    description         = "Alarma si el uso de CPU supera el 70% en el servicio ECS properties."
    actions_enabled     = true
    alarm_actions       = ["arn:aws:autoscaling:us-east-1:721351533107:scalingPolicy:...:resource/ecs/service/cluster_name/properties:policyName/cpu-target-tracking-properties"]
    ok_actions          = []
    dimensions = {
      ClusterName = "travelhub-dev"
      ServiceName = "travelhub-properties"
    }
    treat_missing_data = "missing"
  },
  {
    name                = "ecs-cpu-utilization-high-search"
    comparison_operator = "GreaterThanThreshold"
    evaluation_periods  = 1
    metric_name         = "CPUUtilization"
    namespace           = "AWS/ECS"
    period              = 60
    statistic           = "Average"
    threshold           = 70
    description         = "Alarma si el uso de CPU supera el 70% en el servicio ECS search."
    actions_enabled     = true
    alarm_actions       = ["arn:aws:autoscaling:us-east-1:721351533107:scalingPolicy:...:resource/ecs/service/cluster_name/search:policyName/cpu-target-tracking-search"]
    ok_actions          = []
    dimensions = {
      ClusterName = "travelhub-dev"
      ServiceName = "travelhub-search"
    }
    treat_missing_data = "missing"
  }
]