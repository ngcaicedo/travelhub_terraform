region  = "us-east-1"
key = "dev/compute/terraform.tfstate"
encrypt = true
bucket  = "travelhub-terraform-state-beta"
