region  = "us-east-1"
key = "dev/data/terraform.tfstate"
encrypt = true
bucket  = "travelhub-terraform-state-beta"
