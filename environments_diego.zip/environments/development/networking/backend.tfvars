region  = "us-east-1"
key = "dev/networking/terraform.tfstate"
encrypt = true
bucket  = "travelhub-terraform-state-beta"
