environment = "dev"

# Acceso público a Postgres (5432) desde Internet, p.ej. para conectar
# DBeaver/DataGrip/IntelliJ al RDS dev. Cambia a ["TU.IP.PUBLICA/32"] para
# restringir solo a tu red. Vacío = sin acceso público.
db_public_access_cidrs = ["0.0.0.0/0"]
