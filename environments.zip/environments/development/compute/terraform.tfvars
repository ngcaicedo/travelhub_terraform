environment          = "dev"
state_bucket         = "travelhub-terraform-state-beta"
desired_count        = 1
cors_allowed_origin  = "https://d1zot6uhy8y2us.cloudfront.net"
